﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ToDoAPI.Models;
using ToDoAPI.ViewModels.ToDo;

namespace ToDoAPI.Controllers
{
    
    public class ToDoAPIController : ApiController
    {
        ToDoContext db = new ToDoContext();

        [HttpGet]
        public IEnumerable<Tasks> TasksList()
        {
            ToDoViewModel todolist = new ToDoViewModel();
            todolist.TaskTable = db.Tasks.ToList();
            return todolist.TaskTable;
        }

        [HttpPost]
        public void AddTask([FromBody] ToDoViewModel mod)
        {
            Tasks AddTask = new Tasks();
            AddTask.TaskName = mod.TaskName;
            db.Tasks.Add(AddTask);
            db.SaveChanges();
            
        }
    }
}
